#include <stddef.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <ctime>
using namespace std;

void inputdata_day(int day, string* name, string* pro, string* risk, string* hospital);
int main(){
    time_t t = time(NULL);
    int s = (int)t%10;
    srand(s);
    string name[20] = {"Elaine", "Bonnie", "Van", "Kelly", "Jessica", "Lisa", "Natasha", "Vivian", "Vicky","Andrew", "Timothy", "Kathleen", "Monica", "Viola", "Alice", "John", "Kevin", "Heather", "Hale", "Barbara"};
    string age[7] = {"children", "adolescents", "young_adults", "adults", "seniors", "elderly", "old"};
    string risk[4] = {"no_risk", "low_risk", "medium_risk", "high_risk"};
    string pro[8] = {"pro_1", "pro_2", "pro_3", "pro_4", "pro_5", "pro_6", "pro_7", "pro_8"};
    string hospital[3] = {"hospital_1", "hospital_2", "none"};
    string local = "local_1";
    int n = 10;
    int id_n = 5;
    ofstream outfile;
    outfile.open("temp.txt", ios::out);
    for(int i = 0; i < n; i ++){
        string temp;
        string id = "";
        string contact = "";
        //id
        for(int j = 0; j < id_n; j ++){
            id.append(to_string(rand()%10));
        }
        temp.append(id);
        temp.append(" ");

        //id2
        string id2 = "";
        for(int j = 0; j < id_n; j ++){
            id2.append(to_string(rand()%10));
        }
        temp.append(id2);
        temp.append(" ");

        //id3
        string id3 = "";
        for(int j = 0; j < id_n; j ++){
            id3.append(to_string(rand()%10));
        }
        temp.append(id3);
        temp.append(" ");

        //id4
        string id4 = "";
        for(int j = 0; j < id_n; j ++){
            id4.append(to_string(rand()%10));
        }
        temp.append(id4);
        temp.append(" ");
        //name
        temp.append(name[i]);
        temp.append(" ");
        
        //contact
        for(int j = 0; j < 8; j ++){
            contact.append(to_string(rand()%10));
        }
        temp.append(contact);
        temp.append(" ");   

        //pro
        temp.append(pro[rand()%4]);
        temp.append(" ");     

        //birth
        string birth;
        birth.append(to_string(rand()%2022));
        birth.append("/");
        birth.append(to_string(rand()%13));
        birth.append("/");
        birth.append(to_string(rand()%31));
        temp.append(birth);
        temp.append(" ");

        //age
        temp.append(age[rand()%7]);
        temp.append(" ");        

        //risk
        temp.append(risk[rand()%4]);
        temp.append(" ");

        //hospital
        temp.append(hospital[rand()%2]);
        temp.append(" ");

        //treat hospital
        temp.append(hospital[rand()%3]);
        temp.append(" ");

        //local
        temp.append(local);
        temp.append(" ");

        //prio
        temp.append(to_string(0));
        temp.append(" ");

        //appoit
        temp.append("-1");
        temp.append(" ");

        //time
        temp.append(to_string(rand()%9 + 8));
        temp.append(" ");

        //reg time
        temp.append(to_string(rand()%10));
        temp.append(" ");

        //treat
        temp.append("0");
        temp.append(" ");

        //change
        temp.append("0");
        temp.append(" ");

        //withdraw
        temp.append(to_string(rand()%3-1));
        temp.append(" \n");
        outfile<<temp;

    }
    outfile.close();
    remove("local.txt");
    cout<<rename("temp.txt", "local.txt");

    ofstream inputdata;
    inputdata.open("temp.txt");
    for(int i = 0; i < n; i ++){
        string temp;
        string id = "";
        string contact = "";
        //id
        for(int j = 0; j < id_n; j ++){
            id.append(to_string(rand()%10));
        }
        temp.append(id);
        temp.append(" ");

        //name
        temp.append(name[i]);
        temp.append(" ");
        
        //contact
        for(int j = 0; j < 11; j ++){
            contact.append(to_string(rand()%10));
        }
        temp.append(contact);
        temp.append(" ");   

        //pro
        temp.append(pro[rand()%4]);
        temp.append(" ");     

        //birth
        string birth;
        birth.append(to_string(rand()%2022));
        birth.append("/");
        birth.append(to_string(rand()%13));
        birth.append("/");
        birth.append(to_string(rand()%31));
        temp.append(birth);
        temp.append(" ");     

        //risk
        temp.append(risk[rand()%4]);
        temp.append(" ");

        //hospital
        temp.append(hospital[rand()%2]);
        temp.append(" ");

        //prio
        temp.append(to_string(rand()%2));
        temp.append(" ");

        inputdata<<temp<<endl;
    }

    inputdata.close();
    remove("inputdata.txt");
    rename("temp.txt", "inputdata.txt");
    
    for(int i = 0; i <= 7; i ++){
        inputdata_day(i, name, pro, risk, hospital);
    }
    



    ofstream center;
    center.open("temp.txt", ios::out);
    for(int i = 0; i < n; i ++){
        string temp;
        string id = "";
        string contact = "";
        //id
        for(int j = 0; j < id_n; j ++){
            id.append(to_string(rand()%10));
        }
        temp.append(id);
        temp.append(" ");

        //name
        temp.append(name[i]);
        temp.append(" ");
        
        //contact
        for(int j = 0; j < 11; j ++){
            contact.append(to_string(rand()%10));
        }
        temp.append(contact);
        temp.append(" ");   

        //pro
        temp.append(pro[rand()%4]);
        temp.append(" ");     

        //birth
        string birth;
        birth.append(to_string(rand()%2022));
        birth.append("/");
        birth.append(to_string(rand()%13));
        birth.append("/");
        birth.append(to_string(rand()%31));
        temp.append(birth);
        temp.append(" ");

        //age
        temp.append(age[rand()%7]);
        temp.append(" ");        

        //risk
        temp.append(risk[rand()%4]);
        temp.append(" ");

        //hospital
        temp.append(hospital[rand()%2]);
        temp.append(" ");

        //treat hospital
        temp.append(hospital[rand()%2]);
        temp.append(" ");

        //prio
        temp.append(to_string(rand()%2));
        temp.append(" ");

        //appoit
        temp.append(to_string(rand()%10));
        temp.append(" ");

        //reg time
        temp.append(to_string(rand()%10));
        temp.append(" ");

        //treat
        temp.append("0");
        temp.append(" ");

        //change
        temp.append("0");
        temp.append(" \n");

        center<<temp;
    }
    center.close();
    remove("center.txt");
    cout<<rename("temp.txt", "center.txt");
}

void inputdata_day(int day, string* name, string* pro, string* risk, string* hospital){
    ofstream inputdata;
    string data = "inputdata";
    data.append(to_string(day));
    data.append(".txt");
    inputdata.open("temp.txt", ios::app);
    int n = rand()%20 + 10;
    int id_n = 10;
    for(int i = 0; i < n; i ++){
        string temp;
        string id = "";
        string contact = "";
        //id
        for(int j = 0; j < id_n; j ++){
            id.append(to_string(rand()%10));
        }
        temp.append(id);
        temp.append(" ");

        //name
        temp.append(name[rand()%10]);
        temp.append(" ");
        
        //contact
        for(int j = 0; j < 11; j ++){
            contact.append(to_string(rand()%10));
        }
        temp.append(contact);
        temp.append(" ");   

        //pro
        temp.append(pro[rand()%4]);
        temp.append(" ");     

        //birth
        string birth;
        birth.append(to_string(rand()%100 + 1910));
        birth.append("/");
        birth.append(to_string(rand()%13));
        birth.append("/");
        birth.append(to_string(rand()%31));
        temp.append(birth);
        temp.append(" ");     

        //risk
        string risk_status = risk[rand()%4];
        temp.append(risk_status);
        temp.append(" ");

        //hospital
        temp.append(hospital[rand()%2]);
        temp.append(" ");

        //prio
        
        if(risk_status == risk[3]){
            temp.append(to_string(rand()%14 + day + 1));
        }
        else{
            temp.append(to_string(0));
        }
        temp.append(" ");
        inputdata<<temp<<endl;
    }
    inputdata.close();
    remove(data.c_str());
    cout<<rename("temp.txt", data.c_str());
}