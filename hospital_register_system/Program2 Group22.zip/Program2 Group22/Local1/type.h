#ifndef type_h
#define type_h

//some type used for operation
typedef enum{
    children, //12
    adolescents, //18
    young_adults, //35
    adults, //50
    seniors, //65
    elderly, //75
    old 
    } age_group_type;

typedef enum{
    no_risk, 
    low_risk, 
    medium_risk,
    high_risk
} risk_status_type;

typedef enum{
    pro_1,
    pro_2,
    pro_3,
    pro_4,
    pro_5,
    pro_6,
    pro_7,
    pro_8
} profession_type;

typedef enum
{
    hospital_1,
    hospital_2,
    none
} hospital_type;

#endif