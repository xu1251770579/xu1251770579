#include <string>
#include <cstring>
#include <iostream>
using namespace std;
int name2num(string name){
    char name_char[20];
    int num = 0;
    strcpy(name_char, name.c_str());
    int n = 0;
    while(name_char[n] != '\0'){
        num += name_char[n];
        n ++;
        cout<<n<<endl;
    }

    return num;
}
int main(){
    string name = "Andrew";
    cout<<name2num(name)<<endl;
}