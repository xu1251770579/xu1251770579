#include "Register.h"
#include <stddef.h>
#include "person.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <ctime>
#include "function.h"

/*
function name: treat_operation

input: information list, time

function: modeling the treat operation

output: none
*/
void treat_operation(List* person_list, int day){
    //set random seed
    time_t s;
    s = time(NULL);
    int t = (int)s%100;
    srand(t);
    int n = person_list->getnum();

    //read people who have appointment this day
    for(int i = 0; i < n; i ++){
        List_node* pt = person_list->get_by_index(i);

        //randomly decide people who may miss the treatment
        if(pt->getappoint() == day){
            int attend = rand()%3 - 1;
            if(attend < 0){
                cout<<pt->getid()<<" "<<pt->getname()<<" Miss the treatment"<<endl;
                pt->setwithdraw(day);
                continue;
            }

            int treat = pt->gettreatent();

            pt->settreat(3 + treat);
            cout<<pt->getid()<<" "<<pt->getname()<<" finish treatment"<<endl;
        }
    }
}