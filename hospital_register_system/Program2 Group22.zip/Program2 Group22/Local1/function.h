#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <cstring>
#include "type.h"
using namespace std;
#ifndef function_h
#define function_h
/*this is a set of help function*/

/*
function name: setpro

input: the string of profession type

output: the enum type of profession
*/
profession_type setpro(string prof){
    if(prof == "pro_1"){
        return pro_1;
    }

    if(prof == "pro_2"){
        return pro_2;
    }

    if(prof == "pro_3"){
        return pro_3;
    }

    if(prof == "pro_4"){
        return pro_4;
    }

    if(prof == "pro_5"){
        return pro_5;
    }

    if(prof == "pro_6"){
        return pro_6;
    }

    if(prof == "pro_7"){
        return pro_7;
    }

    if(prof == "pro_8"){
        return pro_8;
    }
    return pro_1;
}

/*
function name: setage

input: the string of age type

output: the enum type of age
*/
age_group_type setage(string age){
    if(age == "children"){
        return children;
    }

    if(age == "adolescents"){
        return adolescents;
    }

    if(age == "young_adults"){
        return young_adults;
    }

    if(age == "adults"){
        return adults;
    }

    if(age == "seniors"){
        return seniors;
    }

    if(age == "elderly"){
        return elderly;
    }

    if(age == "old"){
        return old;
    }
    return old;
}

/*
function name: setrisk

input: the string of risk status

output: the enum type of risk status
*/
risk_status_type setrisk(string risk){
    if(risk == "no_risk"){
        return no_risk;
    }

    if(risk == "low_risk"){
        return low_risk;
    }

    if(risk == "medium_risk"){
        return medium_risk;
    }

    if(risk == "high_risk"){
        return high_risk;
    }
    return high_risk;
}

/*
function name: sethospital

input: the string of hospital type

output: the enum type of hospital
*/
hospital_type sethospital(string hospital){
    if(hospital == "hospital_1"){
        return hospital_1;
    }

    if(hospital == "hospital_2"){
        return hospital_2;
    }
    return none;
}

/*
function name: str_pro_type

input: the enum type of profession

output: string of profession
*/
string str_pro_tye(profession_type pro){
    switch (pro){
        case pro_1:
            return "pro_1";
        
        case pro_2:
            return "pro_2";
        
        case pro_3:
            return "pro_3";
        
        case pro_4:
            return "pro_4";
        
        case pro_5:
            return "pro_5";
        
        case pro_6:
            return "pro_6";

        case pro_7:
            return "pro_7";

        case pro_8:
            return "pro_8";
    }
    return "pro_8";
}

/*
function name: str_age_type

input: the enum type of age

output: string of age type
*/
string str_age_tye(age_group_type age){
    switch (age){
        case children:
            return "children";

        case adolescents:
            return "adolescents";

        case young_adults:
            return "young_adults";

        case adults:
            return "adults";

        case seniors:
            return "seniors";

        case elderly:
            return "elderly";

        case old:
            return "old";
            
    }
    return "old";
}

/*
function name: str_risk_type

input: the enum type of risk status

output: string of risk status
*/
string str_risk_tye(risk_status_type risk){
    switch (risk){
        case no_risk:
            return "no_risk";

        case low_risk:
            return "low_risk";

        case medium_risk:
            return "medium_risk";

        case high_risk:
            return "high_risk";
    }

    return "high_risk";
}

/*
function name: str_hospital_type

input: the enum type of hospital type

output: string of hospital
*/
string str_hosp_tye(hospital_type hosp){
    switch (hosp){
        case hospital_1:
            return "hospital_1";

        case hospital_2:
            return "hospital_2";

        default:
            return "none";
    }

    return "hospital_2";
}

int name2num(string name){
    char name_char[20];
    int num = 0;
    strcpy(name_char, name.c_str());
    int n = 0;
    while(name_char[n] != '\0'){
        num += name_char[n];
        n ++;
    }

    return num;
}

#endif