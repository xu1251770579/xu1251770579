#include "person.h"
#include <fstream>
#include <sstream>
#include <iostream>
#ifndef Register_h
#define Register_h
using namespace std;
class List;

/*class used for single linked list*/

/*node class*/
class List_node
{
    friend class List;

public:
    bool getchange(){
        return data->change;
    }

    string getid(){
        return data->id;
    }

    List_node* getnext(){
        return next;
    }
    void setdata(person* inf){
        data = inf;
    }
    void setnext(List_node* pt){
        next = pt;
    }
    void setchange(bool n){
        data->change = n;
    }
    void display(){
        cout<<data->id<<" ";
        cout<<data->name<<" ";
        cout<<data->contact<<" ";
        cout<<str_pro_tye(data->pro)<<" ";
        cout<<data->birth<<" ";
        cout<<str_age_tye(data->age_group)<<" ";
        cout<<str_risk_tye(data->risk_status)<<" ";
        cout<<str_hosp_tye(data->hospital)<<" ";
        cout<<str_hosp_tye(data->hospital_treat)<<" ";
        cout<<data->local<<" ";
        cout<<data->priority_letter<<" ";
        cout<<data->appointment<<" ";
        cout<<data->time<<" ";
        cout<<data->register_time<<" ";
        cout<<data->treatment<<" ";
        cout<<data->change<<" ";
        cout<<data->withdraw<<" \n";
    }

    int gettime(){
        return data->time;
    }
    

    void printdata(string path){
        ofstream outfile;
        outfile.open(path,ios::app);
        outfile<<data->id<<" ";
        outfile<<data->name<<" ";
        outfile<<data->contact<<" ";
        outfile<<str_pro_tye(data->pro)<<" ";
        outfile<<data->birth<<" ";
        outfile<<str_age_tye(data->age_group)<<" ";
        outfile<<str_risk_tye(data->risk_status)<<" ";
        outfile<<str_hosp_tye(data->hospital)<<" ";
        outfile<<str_hosp_tye(data->hospital_treat)<<" ";
        outfile<<data->local<<" ";
        outfile<<data->priority_letter<<" ";
        outfile<<data->appointment<<" ";
        outfile<<data->register_time<<" ";
        outfile<<data->treatment<<" ";
        outfile<<data->change<<" ";
        outfile<<data->withdraw<<" \n";
        outfile.close();
    }

    void setpro(profession_type pro_){
        data->pro = pro_;
    }

    void setrisk(risk_status_type risk_){
        data->risk_status = risk_;
    }

    void setwithdraw(int day){
        data->withdraw = day;
    }

    int getwithdraw(){
        return data->withdraw;
    }

    int getappoint(){
        return data->appointment;
    }

    int getregtime(){
        return data->register_time;
    }

    risk_status_type getrisk(){
        return data->risk_status;
    }

    void sethospital_treat(hospital_type hosp){
        data->hospital_treat = hosp;
    }

    void setappoint(int day){
        data->appointment = day;
    }

    void settreat(int n){
        data->treatment = n;
    }

    string getname(){
        return data->name;
    }

    void setlocal(string local){
        data->local = local;
    }

    void settime(int time){
        data->time = time;
    }

    int gettreatent(){
        return data->treatment;
    }


private:  
    person* data;
    List_node* next = NULL;
    
};

/*class for list*/
class List{
public: 
    void append(person* inf){
        if(inf == NULL){
            return;
        }
        List_node* pt = new List_node;
        pt->data = inf;
        pt->setchange(1);
        if(num == 0){
            first = pt;
            last = pt;
            num ++;
            return;
        }
        last->setnext(pt);
        last = pt;
        num ++;
    }
    void search(int id)
    {
        List_node* pt = first;
        while (pt!=NULL)
        {
            if (stoi(pt->getid())==id)
            {
                cout<<"\n";
                cout<<pt->data->id<<" ";
                cout<<pt->data->name<<" ";
                cout<<pt->data->contact<<" ";
                cout<<str_pro_tye(pt->data->pro)<<" ";
                cout<<pt->data->birth<<" ";
                cout<<str_age_tye(pt->data->age_group)<<" ";
                cout<<str_risk_tye(pt->data->risk_status)<<" ";
                cout<<str_hosp_tye(pt->data->hospital)<<" ";
                cout<<str_hosp_tye(pt->data->hospital_treat)<<" ";
                cout<<pt->data->local<<" ";
                cout<<pt->data->priority_letter<<" ";
                cout<<pt->data->appointment<<" ";
                cout<<pt->data->register_time<<" ";
                cout<<pt->data->treatment<<" ";
                cout<<pt->data->change<<" ";
                cout<<pt->data->withdraw<<" \n";
                return;
            }
            pt=pt->next;
        }

    }
    void search_m(int id)
    {
        List_node* pt = first;
        while (pt!=NULL)
        {
            if (stoi(pt->data->medical_id)==id)
            {
                cout<<"\n";
                cout<<"risk state is:"<<pt->data->risk_status;
                return;
            }
            pt=pt->next;
        }

    }
    void search_r(int id)
    {
        List_node* pt = first;
        while (pt!=NULL)
        {
            if (stoi(pt->data->regis_id)==id)
            {
                cout<<"\n";
                cout<<"register time is:"<<pt->data->register_time;
                return;
            }
            pt=pt->next;
        }

    }
    void search_t(int id)
    {
        List_node* pt = first;
        while (pt!=NULL)
        {
            if (stoi(pt->data->treat_id)==id)
            {
                cout<<"\n";
                cout<<"treatment state is:"<<pt->data->treatment;
                return;
            }
            pt=pt->next;
        }

    }

    void previous_append(person* inf){
        List_node* pt = new List_node;
        pt->data = inf;
        if(num == 0){
            first = pt;
            last = pt;
            num ++;
            return;
        }
        last->setnext(pt);
        last = pt;
        num ++;
    }

    void display(){
        List_node* pt = first;
        while(pt != NULL){
            pt->display();

            pt = pt->getnext();
        }
    }

    int getnum(){
        return num;
    }

    List_node* getdata(string id){
        List_node* pt = first;
        while(pt->getnext() != 0 && pt->getid() != id){
            pt = pt->getnext();
        }

        if(pt->getid() == id){
            return pt;
        }

        cout<<"Now such person!"<<endl;
        return NULL;
    }

    List_node* get_by_index(int n){
        if(n > num){
            cout<<"out of range"<<endl;
            return NULL;
        }
        List_node* pt = first;
        for(int i = 0; i < n; i ++){
            pt = pt->getnext();
        }

        return pt;
    }

    List_node* get_by_id(string id){
        List_node* pt = first;
        while(pt != NULL){
            if(pt->getid() == id){
                break;
            }
            pt = pt->getnext();
        }
        if (pt == NULL){
            return NULL;
        }

        return pt;
    }

private:
    int num = 0;
    List_node* first;
    List_node* last;

};


#endif