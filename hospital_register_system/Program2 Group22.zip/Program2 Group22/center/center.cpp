#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include "FibHeap.h"
#include "FibHeap_Func_1.h"
#include "FibHeap_Func_2.h"
#include <fstream>
#include <sstream> 
#include <string>
#include <stddef.h>
using namespace std;

int main()
{
    center center1;
    cout<<"Welcome to central system"<<endl;
    while(1){
        cout<<"       today is the "<<center1.time<<"day\n";
        
        cout<<"Please choose your service"<<endl;
        //the command 6 is make one day appointment that is 16 patient one day
        //the next day command will pass one day
        //data in will get the information from the local
        cout<<"1.make appointment   2.data_in   3.dispaly 4. next_day 5.find id 6.decrease 7.make 16 appointment"<<endl;
        int choice;
        //the capicity of one hospital is 8 per day
        static int hos_num_1=0;
        static int hos_num_2=0; 
        cin>>choice;
        string ids;
        switch (choice){
            //make one person appointment
            case 1:
                if(hos_num_1 == 8&&hos_num_2==8){
                    cout<<"hospital is full";
                    break;
                }
                if(center1.pt_min != NULL){
                    if(center1.ddl_person_num != 0 && center1.ddl_person[0]->priority_letter == center1.time+1){
                        center1.ddl_person[0]->appointment = center1.time+1;
                        if(center1.ddl_person[0]->hospital == "hospital_1"){
                            if(hos_num_1 < 8){
                                hos_num_1++;
                                center1.ddl_person[0]->treat_hospital = "hospital_1";
                            }else{
                                hos_num_2++;
                                center1.ddl_person[0]->treat_hospital = "hospital_2";
                            }
                        }else{
                            if(hos_num_2 < 8){
                                hos_num_2++;
                                center1.ddl_person[0]->treat_hospital = "hospital_2";
                            }else{
                                hos_num_1++;
                                center1.ddl_person[0]->treat_hospital = "hospital_1";
                            }
                        } 
                        fib_node* a;
                        a=center1.find(center1.pt_min,center1.ddl_person[0]->id);
                        center1.deliver_back(a,hos_num_1,hos_num_2);
                        //arrange_time(a,hos_num_1,hos_num_2);
                        center1.file_delete(a);
                        center1.delete_person(center1.ddl_person[0]->id);
                        center1.delete_ddl(center1.ddl_person[0]->id);
                        
                    }else{
                        center1.pt_min->node_person->appointment = center1.time+1;
                        if(center1.pt_min->node_person->hospital == "hospital_1"){
                            if(hos_num_1 < 8){
                                hos_num_1++;
                                center1.pt_min->node_person->treat_hospital = "hospital_1";
                            }else{
                                hos_num_2++;
                                center1.pt_min->node_person->treat_hospital = "hospital_2";
                            }
                        }else{
                            if(hos_num_2 < 8){  
                                hos_num_2++;
                                center1.pt_min->node_person->treat_hospital = "hospital_2";
                            }else{
                                hos_num_1++;
                                center1.pt_min->node_person->treat_hospital = "hospital_1";
                            }
                        }
                        center1.deliver_back(center1.pt_min,hos_num_1,hos_num_2);
                        //arrange_time(center1.pt_min,hos_num_1,hos_num_2);
                        center1.file_delete(center1.pt_min);
                        if(center1.pt_min->node_person->priority_letter>0){
                            center1.delete_ddl(center1.pt_min->node_person->id);
                        }
                        center1.delete_min();
                    }
                }else{
                    cout<<"have no patient in the tree\n";
                }
                break;
            case 2:
                center1.update();
                break;
            case 3:
                center1.display();
                break;
            case 4:
                while(center1.ddl_person[0]->priority_letter==center1.time+1){
                    fib_node* a;
                    a=center1.find(center1.pt_min,center1.ddl_person[0]->id);
                    center1.file_delete(a);
                    center1.delete_person(center1.ddl_person[0]->id);
                    center1.delete_ddl(center1.ddl_person[0]->id);
                }
                center1.time++;
                hos_num_1 = 0;
                hos_num_2 = 0;
                break;
            case 5:
                fib_node* a;
                cin>>ids;
                a = center1.find(center1.pt_min,ids);
                if(a == NULL){
                    cout<<"NULL\n";
                }else{
                    cout<<a->node_person->id<<"\n";
                }
                break;
            case 6:
                cin>>ids;
                center1.decrease(ids);
                break;

            case 7:
                for(int i=0;i<16;i++){
                    if(hos_num_1 == 8&&hos_num_2==8){
                        cout<<"hospital is full";
                        break;
                    }
                    if(center1.pt_min != NULL){
                        if(center1.ddl_person_num != 0 && center1.ddl_person[0]->priority_letter == center1.time+1){
                            center1.ddl_person[0]->appointment = center1.time+1;
                            if(center1.ddl_person[0]->hospital == "hospital_1"){
                                if(hos_num_1 < 8){
                                    hos_num_1++;
                                    center1.ddl_person[0]->treat_hospital = "hospital_1";
                                }else{
                                    hos_num_2++;
                                    center1.ddl_person[0]->treat_hospital = "hospital_2";
                                }
                            }else{
                                if(hos_num_2 < 8){
                                    hos_num_2++;
                                    center1.ddl_person[0]->treat_hospital = "hospital_2";
                                }else{
                                    hos_num_1++;
                                    center1.ddl_person[0]->treat_hospital = "hospital_1";
                                }
                            }
                            fib_node* a;
                            a=center1.find(center1.pt_min,center1.ddl_person[0]->id);
                            center1.deliver_back(a,hos_num_1,hos_num_2);
                            //arrange_time(a,hos_num_1,hos_num_2);
                            center1.file_delete(a);
                            center1.delete_person(center1.ddl_person[0]->id);
                            center1.delete_ddl(center1.ddl_person[0]->id);
                            
                        }else{
                            center1.pt_min->node_person->appointment = center1.time+1;
                            if(center1.pt_min->node_person->hospital == "hospital_1"){
                                if(hos_num_1 < 8){
                                    hos_num_1++;
                                    center1.pt_min->node_person->treat_hospital = "hospital_1";
                                }else{
                                    hos_num_2++;
                                    center1.pt_min->node_person->treat_hospital = "hospital_2";
                                }
                            }else{
                                if(hos_num_2 < 8){
                                    hos_num_2++;
                                    center1.pt_min->node_person->treat_hospital = "hospital_2";
                                }else{
                                    hos_num_1++;
                                    center1.pt_min->node_person->treat_hospital = "hospital_1";
                                }
                            }
                            center1.deliver_back(center1.pt_min,hos_num_1,hos_num_2);
                            //arrange_time(center1.pt_min,hos_num_1,hos_num_2);
                            center1.file_delete(center1.pt_min);
                            if(center1.pt_min->node_person->priority_letter>0){
                                center1.delete_ddl(center1.pt_min->node_person->id);
                            }
                            center1.delete_min();
                        }
                    }else{
                        cout<<"have no patient in the tree\n";
                    }
                }
                break;
            default:
                goto quit;
        }
    }
    quit:
// center center1;
// person person1;
// person person2;
// person person3;
// person person4;
// person person5;
// person person6;
// person person7;
// person person8;
// person person9;
// person person10;
// fib_node node1;
// fib_node node2;
// fib_node node3;
// fib_node node4;
// fib_node node5;
// fib_node node6;
// fib_node node7;
// fib_node node8;
// fib_node node9;
// fib_node node10;

return 0;


}