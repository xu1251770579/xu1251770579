#include <stdlib.h>
#include <string>
using namespace std;
#ifndef FibHeap_h
#define FibHeap_h

class person;

typedef enum{
    children, //12
    adolescents, //18
    young_adults, //35
    adults, //50
    seniors, //65
    elderly, //75
    old 
    } age_group_type;

typedef enum{
    no_risk, 
    low_risk, 
    medium_risk,
    high_risk
} risk_status_type;

typedef enum{
    pro_1,
    pro_2,
    pro_3,
    pro_4,
    pro_5,
    pro_6,
    pro_7,
    pro_8
} profession_type;

// class local
// {

// };

class fib_node
{
    public:
        person* node_person;
        fib_node* child;
        fib_node* parent;
        fib_node* left;
        fib_node* right;
        bool if_mark;
        int32_t degree;
        fib_node(){
            degree = 0;
            child = NULL;
            parent = NULL;
            left = NULL;
            right = NULL;
            if_mark = false;
        }
        fib_node(person* person_){
            degree = 0;
            child = NULL;
            parent = NULL;
            left = NULL;
            right = NULL;
            if_mark = false;
            node_person = person_;
        }
        
};

class center
{   public:
        center(){
            pt_min = NULL;
            node_num = 0;
            ddl_person = NULL;
            time = 0;
            ddl_person = new person*[10000];
            ddl_person_num = 0;
        }
        int compare(fib_node *pt_1,fib_node *pt_2);
        void delete_min();
        void insert(fib_node* node);
        fib_node* find(fib_node* root, string id);
        void decrease(string id);
        void delete_person(string id);
        void consolidate();
        fib_node* extractMin();
        fib_node* link(fib_node* a,fib_node* b);
        void cut(fib_node* parent,fib_node* child);
        void cascading_cut(fib_node* a);
        void display();
        void update();
        void file_delete(fib_node* node);
        void file_appand(fib_node* node);
        void deliver_back(fib_node* node,int num1,int num2);
        void delete_ddl(string id);
        void insert_ddl(person* person_);


        person** ddl_person;
        int ddl_person_num;
        fib_node* pt_min;
        fib_node* pt_min2;
        fib_node* pt_min3;
        int node_num;
        int time; 
        
};

class person
{
    public:
        person(){
            priority_letter = 0;
            appointment = 0;
            register_time = 0;
            treatment = 0;
            change = 0;
            absolute = 0;
        }
        // person(string id_num,string name_,string contact_,profession_type pro_,
        //         string birth_,local hospital_,risk_status_type risk){
        //     int year,age;
        //     id = id_num;
        //     name = name_;//may new
        //     contact = contact_;
        //     pro = pro_;
        //     birth = birth_;
        //     for(int i = 0; i<4 ; i++){
        //         year = year*10 + (birth[i] - '0'); 
        //     }
        //     age = 2021 -year;
        //     if(age<=12){
        //         age_group = children;
        //     }else if(age<=18){
        //         age_group = adolescents;
        //     }else if(age <= 35){
        //         age_group = young_adults;
        //     }else if(age <= 50){
        //         age_group = adults;
        //     }else if(age <= 65){
        //         age_group = seniors;
        //     }else if(age <= 75){
        //         age_group = elderly;
        //     }else{
        //         age_group = old;
        //     }
        //     priority_letter = 0;
        //     appointment = 0;
        //     register_time = 0;
        //     treatment = 0;
        //     change = 0;
        //     absolute = 0;
        //  }
    
        string id;
        string name;
        string contact;
        profession_type pro;
        string birth;
        age_group_type age_group;
        risk_status_type risk_status;
        string hospital;
        string treat_hospital;
        string local;
        int32_t priority_letter;
        int32_t appointment;
        int32_t register_time;
        int treatment;
        bool change;
        int withdraw;
        int absolute;
        

};

#endif 
