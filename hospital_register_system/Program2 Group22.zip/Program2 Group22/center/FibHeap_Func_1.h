#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include "FibHeap.h"
#include <fstream>
#include <sstream>
#include <string>
#include <stddef.h>
#ifndef FibHeap_Func_1_h
#define FibHeap_Func_1_h
using namespace std;

using std::cout;
using std::cin;

profession_type setpro(string prof);
risk_status_type setrisk(string risk);
age_group_type setage(string age);
string pro_to_string(profession_type m);
string age_to_string(age_group_type n);
string risk_to_string(risk_status_type r);


//this function is used to update the information in the central station
//there are mainly 3 step: 1. Read data from the media file (new.txt) 2. Add the data in the fibonacci heap 3. Add the data in the central file (fib.txt)
void center::update()                       
{
    //open the input file
    ifstream infile;
    infile.open("new.txt",ios::in);
    //use a while loop to read the file until the end
    while (infile.eof()==0)
    {
        string temp;
        getline(infile,temp);
        if (temp=="")
        {
            break;
        }
        //cout<<temp<<endl;
        string id;
        size_t id_pt=0;
        //if the person is already in the heap, delete it and delete it from the center file
        id_pt=temp.find(" ",0);
        id=temp.substr(0,id_pt);
        fib_node* new_node=new fib_node;
        new_node->node_person=new person;
        new_node->node_person->id=id;
        if (this->find(pt_min,id)!=NULL)
        {
            //cout<<"find one\n";
            this->delete_ddl(id);
            this->file_delete(new_node);
            this->delete_person(id);
        }
        //use two pointers to extract the informations and fill it in the newly created node
        size_t p1=0;
        size_t p2=0;
        for (int i = 0; i < 16; i++)
        {
            string item;
            p1=p2;
            p2=temp.find(" ",p1);
            item=temp.substr(p1,p2-p1);
            p2++;
            switch (i)
            {
            case 0:
                new_node->node_person->id=item;
                break;
            case 1:
                new_node->node_person->name=item;
                break;
            case 2:
                new_node->node_person->contact=item;
                break;
            case 3:
                new_node->node_person->pro=setpro(item);
                break;
            case 4:
                new_node->node_person->birth=item;
                break;
            case 5:
                new_node->node_person->age_group=setage(item);
                break;
            case 6:
                new_node->node_person->risk_status=setrisk(item);
                break;
            case 7:
                new_node->node_person->hospital=item;
                break;
            case 8:
                new_node->node_person->treat_hospital=item;
                break;
            case 9:
                new_node->node_person->local=item;
                break;
            case 10:
                new_node->node_person->priority_letter=stoi(item);
                break;
            case 11:
                new_node->node_person->appointment=stoi(item);
                break;
            case 12:
                new_node->node_person->register_time=stoi(item);
                break;
            case 13:
                new_node->node_person->treatment=stoi(item);
                break;
            case 14:
                new_node->node_person->change=stoi(item);
                break;
            case 15:
                new_node->node_person->withdraw=stoi(item);
                break;
            }
        }
        
        //add the new node in the heap and append the data in the file
        if (new_node->node_person->withdraw<0)
        {
            this->insert_ddl(new_node->node_person);
            this->insert(new_node);
            this->file_appand(new_node);
        
        }
    }    
    infile.close();
    return;

}

//this function is used to add a line of data in the center file
void center::file_appand(fib_node* node)
{
    ofstream outfile;
    //print the elements of the node class one by one
    outfile.open("fib.txt",ios::app);
    outfile<<node->node_person->id<<" ";
    outfile<<node->node_person->name<<" ";
    outfile<<node->node_person->contact<<" ";
    outfile<<pro_to_string(node->node_person->pro)<<" ";
    outfile<<node->node_person->birth<<" ";
    outfile<<age_to_string(node->node_person->age_group)<<" ";
    outfile<<risk_to_string(node->node_person->risk_status)<<" ";
    outfile<<node->node_person->hospital<<" ";
    outfile<<node->node_person->treat_hospital<<" ";
    outfile<<node->node_person->local<<" ";
    outfile<<node->node_person->priority_letter<<" ";
    outfile<<node->node_person->appointment<<" ";
    outfile<<node->node_person->register_time<<" ";
    outfile<<node->node_person->treatment<<" ";
    outfile<<node->node_person->change<<" ";
    outfile<<node->node_person->withdraw<<" ";
    outfile<<"\n";
    outfile.close();
    ofstream outfile_2;
    outfile_2.open("new.txt",ios::out);
    outfile_2.close();

}

//this function is used to remove a certain line of data from the file by comparing its id
void center::file_delete(fib_node* node)
{
    ofstream outfile;
    ifstream infile;
    outfile.open("temp.txt",ios::out);
    infile.open("fib.txt",ios::in);
    string temp,id;
    while (infile.eof()==0)
    {
        getline(infile,temp);
        if (temp=="")
        {
            break;
        }
        size_t id_pt=0;
        id_pt=temp.find(" ",0);
        id=temp.substr(0,id_pt);
        if (id!=node->node_person->id)
        {
            outfile<<temp<<"\n";
        }
    }
    infile.close();
    outfile.close();
    remove("fib.txt");
    rename("temp.txt","fib.txt");   
}

//this function is used to deliver a line of data back to the local station
void center::deliver_back(fib_node* node,int num1,int num2)
{
    ofstream outfile;
    if (node->node_person->local=="local_1")
    {
        outfile.open("../Local1/new.txt",ios::app);
    }
    else{
        outfile.open("../Local2/new.txt",ios::app);
    }
    
    outfile<<node->node_person->id<<" ";
    outfile<<node->node_person->name<<" ";
    outfile<<node->node_person->contact<<" ";
    outfile<<pro_to_string(node->node_person->pro)<<" ";
    outfile<<node->node_person->birth<<" ";
    outfile<<age_to_string(node->node_person->age_group)<<" ";
    outfile<<risk_to_string(node->node_person->risk_status)<<" ";
    outfile<<node->node_person->hospital<<" ";
    outfile<<node->node_person->treat_hospital<<" ";
    outfile<<node->node_person->priority_letter<<" ";
    outfile<<node->node_person->appointment<<" ";
    outfile<<node->node_person->register_time<<" ";
    outfile<<node->node_person->treatment<<" ";
    outfile<<node->node_person->change<<" ";
    if (node->node_person->treat_hospital=="hospital_1")
    {
        outfile<<num1<<" ";
    }
    else{outfile<<num2<<" ";}
    outfile<<"\n";
    outfile.close();

}



//functions used to convert enum to string and reversely.
profession_type setpro(string prof)
{
    if(prof == "pro_1"){
        return pro_1;
    }

    if(prof == "pro_2"){
        return pro_2;
    }

    if(prof == "pro_3"){
        return pro_3;
    }

    if(prof == "pro_4"){
        return pro_4;
    }

    if(prof == "pro_5"){
        return pro_5;
    }

    if(prof == "pro_6"){
        return pro_6;
    }

    if(prof == "pro_7"){
        return pro_7;
    }
    else
        return pro_8;
}

age_group_type setage(string age){
    if(age == "children"){
        return children;
    }

    if(age == "adolescents"){
        return adolescents;
    }

    if(age == "young_adults"){
        return young_adults;
    }

    if(age == "adults"){
        return adults;
    }

    if(age == "seniors"){
        return seniors;
    }

    if(age == "elderly"){
        return elderly;
    }

    if(age == "old"){
        return old;
    }
    return old;
}

risk_status_type setrisk(string risk){
    if(risk == "no_risk"){
        return no_risk;
    }

    if(risk == "low_risk"){
        return low_risk;
    }

    if(risk == "medium_risk"){
        return medium_risk;
    }

    if(risk == "high_risk"){
        return high_risk;
    }
    return high_risk;
}

string pro_to_string(profession_type m){
    if(m == pro_1){
        return "pro_1";
    }
    else if(m == pro_2){
        return "pro_2";
    }
    else if(m == pro_3){
        return "pro_3";
    }
    else if(m == pro_4){
        return "pro_4";
    }
    else if(m == pro_5){
        return "pro_5";
    }
    else if(m == pro_6){
        return "pro_6";
    }
    else if(m == pro_7){
        return "pro_7";
    }
    else if(m == pro_8){
        return "pro_8";
    }
}

string age_to_string(age_group_type n){
    if(n == children){
        return "children";
    }
    else if(n == adolescents){
        return "adolescents";
    }
    else if(n == young_adults){
        return "young_adults";
    }
    else if(n == adults){
        return "adults";
    }
    else if(n == seniors){
        return "seniors";
    }
    else if(n == elderly){
        return "elderly";
    }
    else if(n == old){
        return "old";
    }
}

string risk_to_string(risk_status_type r){
    if(r == no_risk){
        return "no_risk";
    }
    else if(r == low_risk){
        return "low_risk";
    }
    else if(r == medium_risk){
        return "mediun_risk";
    }
    else if(r == high_risk){
        return "high_risk";
    }
}

#endif