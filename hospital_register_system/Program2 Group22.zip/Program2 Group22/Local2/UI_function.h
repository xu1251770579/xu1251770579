#include "Register.h"
#include "person.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include "function.h"
#include <ctime>
#include "hashset.h"
using namespace std;
#ifndef UI_function_h
#define UI_function_h

/*
function name: get_single_person

input: day, list, location

function: record single people's information by input

output: item of person
*/
person* get_singe_person(int day, List* person_list, string local, hashset<person>* hashtable){
    time_t t = time(NULL);
    int s = (int)t%10;
    srand(s);
    string id, name, contact, pro, birth, hosp, risk, prio;
    cout<<"Please Enter Infomation As Instruction"<<endl;
    cout<<"id:";
    cin>>id;
    cout<<"name:";
    cin>>name;
    cout<<"contact:";
    cin>>contact;
    cout<<"Profession:";
    cin>>pro;
    profession_type pro_ = setpro(pro);
    cout<<"Birth:";
    cin>>birth;
    cout<<"Nearest hospital";
    cin>>hosp;
    hospital_type hosp_ = sethospital(hosp);
    cout<<"Risk Status";
    cin>>risk;
    risk_status_type risk_ = setrisk(risk);
    cout<<"Priority Letter";
    cin>>prio;
    if(person_list->get_by_id(id) != NULL){
        cout<<"id already exist!"<<endl;
        return NULL;
    }
    person* info = new person(id, name, contact, pro_, birth, hosp_, risk_);
    info->hospital_treat = none;
    info->register_time = day;
    info->withdraw = -1;
    info->priority_letter = stoi(prio);
    info->local = local;
    info->treatment = rand()%3 + 1;
    hashtable->add(info);
    return info;
}

/*
function name: viewdata

input: list

function: inqure data

output: none
*/
void viewdata(List* data, hashset<person>* hashtable){
    cout<<"choose your operation"<<endl;
    cout<<"1.list all   2.inquire by id 3.inquire by name"<<endl;
    int choice;
    cin>>choice;
    string id;
    string name;
    List* info;
    switch (choice){
        case 1:
            data->display();
            break;

        case 2: 
            cout<<"Please enter id:";
            cin>>id;
            data->get_by_id(id)->display();
            break;

        case 3:
            cout<<"Please enter name:";
            cin>>name;
            info = hashtable->member(name);
            if (info->getnum() == 0){
                cout<<"None such person"<<endl;
                delete info;
                break;
            }
            info->display();
            delete info;

        default:
            break;
    }

}

/*
function name: sentdata

input: list, time

function: sent data to center

output: none
*/
void sentdata(List* data, int day){
    fstream _center;

    _center.open("../center/new.txt");
    if(! _center){
        cout<<"Center access fail! Please check conection"<<endl;
        return;
    }
    _center.close();

    ofstream center;
    int n = data->getnum();
    string path = "\\\\../center/new.txt";
    int count = 0;
    for (int i = 0; i < n; i ++){
        if(data->get_by_index(i)->getchange() == 1 ){
            if(data->get_by_index(i)->getrisk() == medium_risk && 30 - data->get_by_index(i)->getregtime() > 0){
                continue;
            }
            data->get_by_index(i)->printdata(path);
            data->get_by_index(i)->setchange(0);
            count ++;
        }

        if(day - data->get_by_index(i)->getwithdraw() == 14 && data->get_by_index(i)->getwithdraw() >= 0){
            data->get_by_index(i)->setwithdraw(-2);
            data->get_by_index(i)->printdata(path);
            count++;
        }
    }
    cout<<count<<" items have been sent"<<endl;
}

/*
function name: appendall

input: day, list, location

function: record a set of people's information by read data

output: items of person
*/
void appendall(List* person_list, int day, string local, hashset<person>* hashtable){
    ifstream infile;
    string path = "inputdata";
    path.append(to_string(day));
    path.append(".txt");
    infile.open(path);
    cout<<"open file "<<path<<endl;
    int count = 0;
    while(infile.eof() == 0){
        string temp;
        string id, name, contact, birth;
        profession_type pro;
        hospital_type hosp;
        risk_status_type risk;
        int prio;
        getline(infile, temp);
        if(temp.length() == 0){
            break;
        }
        size_t p1 = 0;
        size_t p2 = 0;
        for(int i = 1; i <= 13; i ++){
            string item;
            p1 = p2;
            p2 = temp.find(" ", p1);
            item = temp.substr(p1, p2-p1);
            p2 ++;
            switch (i){
                case 1:
                    id = item;
                    break;

                case 2:
                    name = item;
                    break;

                case 3:
                    contact = item;
                    break;

                case 4:
                    pro = setpro(item);
                    break;

                case 5:
                    birth = item;
                    break;

                case 6:
                    risk = setrisk(item);
                    break;

                case 7:
                    hosp = sethospital(item);
                    break;

                case 8: 
                    prio = stoi(item);
                    break;

                default:
                    break;
            }            
        }
        if(person_list->get_by_id(id) != NULL){
            continue;
        }
        person* info = new person(id, name, contact, pro, birth, hosp, risk);
        info->hospital_treat = none;
        info->register_time = day;
        info->withdraw = -1;
        info->priority_letter = prio;
        info->appointment = -1;
        info->local = local;
        person_list->append(info);
        hashtable->add(info);
        count ++;
    }
    cout<<count<<" new people register"<<endl;
}

/*
function name: renewdata

input: list

function: renew the stored data

output: none
*/
void renew_record(List* person_list){
    string outfile = "temp.txt";
    int n = person_list->getnum();
    for (int i = 0; i < n; i ++){
        person_list->get_by_index(i)->printdata(outfile);
    }
    remove("local.txt");
    rename("temp.txt", "local.txt");
}

/*
function name: change_info

input: list

function: change certain people's profession or risk status

output: none
*/
void change_info(List* person_list){
    string id;
    List_node* pt;
    int choice;
    string new_info;
    cout<<"Your ID"<<endl;
    cin>>id;
    cout<<"inquring..."<<endl;
    pt = person_list->get_by_id(id);
    if(pt == NULL){
        cout<<"Not found"<<endl;
        return;
    }
    cout<<"Modify item: 1.Profession 2.Risk status (press other to quit)"<<endl;
    cin>>choice;
    cout<<"New information"<<endl;
    cin>>new_info;
    switch (choice){
        case 1:
            pt->setpro(setpro(new_info));
            pt->setchange(1);
            break;

        case 2:
            pt->setrisk(setrisk(new_info));
            pt->setchange(1);
            break;

        default:
            break;
    }
}

/*
function name: withdraw

input: day, list

function: withdraw the appointment or register information

output: item of person
*/
void withdraw(List* person_list, int day){
    string id;
    List_node* pt;
    int choice;
    string new_info;
    cout<<"Your ID"<<endl;
    cin>>id;
    cout<<"inquring..."<<endl;
    pt = person_list->get_by_id(id);
    if(pt == NULL){
        cout<<"Not found"<<endl;
        return;
    }
    if(pt->getappoint() <= 0){
        cout<<"No current appointment! Are you sure to withdraw"<<endl;
        cout<<"1.Yes   2.No"<<endl;
        cin>>choice;
        if (choice == 2){
            return;
        }
    }
    cout<<"Withdraw would have to wait extra 14 days. Are you sure to withdraw"<<endl;
    cout<<"1.Yes   2.No"<<endl;
    cin>>choice;
    if(choice == 1){
        pt->setappoint(0);
        pt->setwithdraw(day);
        pt->setchange(1);
    }
}

#endif