#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <string>
#include "local.h"

using namespace std;

/*This function is used to generate the weekly report. It will read the content in the local.txt, anlaysing the data and generating the weekly_report.txt*/
void local_::report1(){
    
    person* obj[10000];
    /*temp1 is used to read the file, while temp2 is used to write the file*/
    string temp1;
    string temp2;
    ifstream infile;
    ofstream outfile;
    size_t p3;
    size_t p4;
    int m = 0;
    infile.open("local.txt",ios::in);
    outfile.open("weekly_report.txt",ios::out);
    
    
    while(infile.eof() == 0)
    {   
        person* person1 = new person;
        /*we read the file line by line*/
        getline(infile, temp1);
        /*if the line is empty, we finish reading*/
        if(temp1 == ""){
            break;
        }
        size_t p3 = 0;
        size_t p4 = 0;
        /*for each line, it always include 17 items, we load the content into the person1 list*/
        for (int i = 0; i < 17; i++){
            /*we get each item from a single line*/
            string item1;
            p3 = p4;
            p4 = temp1.find(" ", p3);
            item1 = temp1.substr(p3, p4-p3);
            p4++;
            /*16 cases are following*/
            switch(i){
                case 0:
                
                    person1->id = item1;
                    
                    break;
                case 1:
                
                    person1->name = item1;
                    break;
                case 2:
                    person1->contact = item1;
                    break;
                case 3:
                    
                    if(item1 == "pro_1") {
                        person1->pro = pro_1;
                    } 
                    else if(item1 == "pro_2"){
                        person1->pro = pro_2;
                    }
                    else if(item1 == "pro_3"){
                        person1->pro = pro_3;
                    }
                    else if(item1 == "pro_4"){
                        person1->pro = pro_4;
                    }
                    else if(item1 == "pro_5"){
                        person1->pro = pro_5;
                    }
                    else if(item1 == "pro_6"){
                        person1->pro = pro_6;
                    }
                    else if(item1 == "pro_7"){
                        person1->pro = pro_7;
                    }
                    else if(item1 == "pro_8"){
                        person1->pro = pro_8;
                    } 
                    break;
                case 4:
                    person1->birth = item1;
                    
                    break;
                case 5:
                    if(item1 == "children"){
                        person1->age_group = children; 
                    }
                    else if(item1 == "adolescents"){
                        person1->age_group = adolescents;
                    }
                    else if(item1 == "young_adults"){
                        person1->age_group = young_adults;
                    }
                    else if(item1 == "adults"){
                        person1->age_group = adults;
                    }
                    else if(item1 == "seniors"){
                        person1->age_group = seniors;
                    }
                    else if(item1 == "elderly"){
                        person1->age_group = elderly;
                    }
                    else if(item1 == "old"){
                        person1->age_group = old;
                    }
                    break;
                case 6:
                    if(item1 == "no_risk"){
                        person1->risk_status = no_risk;
                    }
                    else if(item1 == "low_risk"){
                        person1->risk_status = low_risk;
                    }
                    else if(item1 == "medium_risk"){
                        person1->risk_status = medium_risk;
                    }
                    else if(item1 == "high_risk"){
                        person1->risk_status = high_risk;
                    }
                    
                    break;
                case 7:
                    if(item1 == "hospital_1"){
                        person1->hospital = hospital_1;
                    }
                    else if(item1 == "hospital_2"){
                        person1->hospital = hospital_2;
                    }
                    break;
                case 8:
                    
                    if(item1 == "hospital_1"){
                        person1->hospital_treat = hospital_1;
                    }
                    else if(item1 == "hospital_2"){
                        person1->hospital_treat = hospital_2;
                    }
                    else if(item1 == "none"){
                        person1->hospital_treat = none;
                    }
                    break;    
                case 10:
                    
                    person1->priority_letter = stoi(item1);
                    
                    break;
                    
                case 11:
                    person1->appointment = stoi(item1);
                    break;
                case 12:
                    person1->time = stoi(item1);
                    break;
                case 13:
                    person1->register_time = stoi(item1);
                    break;
                case 14:
                    if (item1 == "1"){
                        person1->treatment = 1;
                    }
                    else if (item1 == "2"){
                        person1->treatment = 2;
                    }
                    else if (item1 == "3"){
                        person1->treatment = 3;
                    }
                    else if (item1 == "4"){
                        person1->treatment = 4;
                    }
                    else if (item1 == "5"){
                        person1->treatment = 5;
                    }
                    else if (item1 == "6"){
                        person1->treatment = 6;
                    }

                    break;
                case 15:
                
                    if (item1 == "1"){
                        person1->change = true;
                    }
                    else if(item1 == "0"){
                        person1->change = false;
                    }
                    break;
                
                case 16:
                    person1->withdraw = stoi(item1);
                    break;

                case 9:
                    person1->local = item1;
                    break;
            }
            
        }          
        obj[m] = person1;
        m++;
        
    }
    
    infile.close();
    /*now we begin to generate the report*/
    /*we firstly find people who have been treated*/
    temp2 = "";
    temp2.append("People who have been treated:\n");
    int signal = 0;
    int num = 0;
    /*treated is used to store the people who have been treated*/
    person* treated[10000];
    for (int k = 0; k <= m-1;k++){
        
        if((obj[k]->treatment >= 4) && ((time - obj[k]->appointment) < 7)){
            signal = 1;
            treated[num] = obj[k];
            num++;
        }
    }
    /*if the list is empty, we report "none"*/
    if (signal == 0){
        temp2.append("None");
        temp2.append("\n");
        temp2.append("\n");
        temp2.append("\n");
        temp2.append("\n");
    }
    /*else we report id, name, profession, age group, risk status and waiting time of treated people*/
    else{
        /*here we sort people by their profession*/
        sort(treated, num);
        for(int i = 0; i<=num-1;i++){
            temp2.append(treated[i]->id);
            temp2.append(" ");

            temp2.append(treated[i]->name);
            temp2.append(" ");

            temp2.append(addpro(treated[i]->pro));
            temp2.append(" ");
            
            temp2.append(addage(treated[i]->age_group));
            temp2.append(" ");

            temp2.append(addrisk(treated[i]->risk_status));
            temp2.append(" ");

            int32_t waiting;
            waiting = treated[i]->appointment - treated[i]->register_time;
            temp2.append(to_string(waiting));

            temp2.append("\n");
            
    }
            temp2.append("\n");
            temp2.append("\n");
            temp2.append("\n");
    }
    /*the next part is to report registered people with a set appointment. It's similar to the previous part*/
    temp2.append("Registered people with a set appointment:\n");
    int signal1 = 0;
    int num1 = 0;
    person* appointment[10000];
    for(int k = 0;k <= m-1; k++){
        if((obj[k]->treatment < 4) && (obj[k]->appointment != 0) && ((time - obj[k]->register_time) < 7) && ((obj[k]->withdraw) == -1)){
            signal1 = 1;
            appointment[num1] = obj[k];
            num1++;
        }
    }
    if (signal1 == 0){
        temp2.append("None");
        temp2.append("\n");
        temp2.append("\n");
        temp2.append("\n");
        temp2.append("\n");
    }
    else{
        sort(appointment, num1);
        for(int i = 0; i<=num1-1;i++){
            temp2.append(appointment[i]->id);
            temp2.append(" ");

            temp2.append(appointment[i]->name);
            temp2.append(" ");

            temp2.append(addpro(appointment[i]->pro));
            temp2.append(" ");
            
            temp2.append(addage(appointment[i]->age_group));
            temp2.append(" ");

            temp2.append(addrisk(appointment[i]->risk_status));
            temp2.append(" ");

            int32_t waiting1;
            waiting1 = time - appointment[i]->register_time;
            temp2.append(to_string(waiting1));

            temp2.append("\n");
            
    }
            temp2.append("\n");
            temp2.append("\n");
            temp2.append("\n");
    }

    /*the third part is to report registered people without a set oppointment*/
    temp2.append("Registered people without a set appointment:\n");
    int num2 = 0;
    person* without[10000];
    int signal2 = 0;
    for(int k = 0;k <= m-1; k++){
        if((obj[k]->treatment < 4) && ((time - obj[k]->register_time) < 7) && ((obj[k]->appointment == 0) || ((obj[k]->appointment != 0) && ((obj[k]->withdraw) != -1)))){
            signal2 = 1;
            without[num2] = obj[k];
            num2++;
            
        }
    }
    if (signal2 == 0){
        temp2.append("None");
        temp2.append("\n");
        ;

    }
    else{
        sort(without, num2);
        for(int i = 0; i<=num2-1;i++){
            temp2.append(without[i]->id);
            temp2.append(" ");

            temp2.append(without[i]->name);
            temp2.append(" ");

            temp2.append(addpro(without[i]->pro));
            temp2.append(" ");
            
            temp2.append(addage(without[i]->age_group));
            temp2.append(" ");

            temp2.append(addrisk(without[i]->risk_status));
            temp2.append(" ");

            int32_t waiting2;
            waiting2 = time - without[i]->register_time;
            temp2.append(to_string(waiting2));

            temp2.append("\n");
    }
    }
    outfile<<temp2;
    outfile.close();

}

/*this function reads "local.txt" and generates "monthly_statistics_report.txt"*/
void local_::report2(){
    person* obj1[10000];
    
    string temp1;
    string temp2;
    ifstream infile;
    ofstream outfile;
    size_t p3;
    size_t p4;
    int m = 0;
    infile.open("local.txt",ios::in);
    outfile.open("monthly_statistics_report.txt",ios::out);
    
    /*the reading part is similar to the report1()*/
    while(infile.eof() == 0)
    {   
        person* person1 = new person;
        getline(infile, temp1);
        if(temp1 == ""){
            break;
        }
        size_t p3 = 0;
        size_t p4 = 0;
        
        for (int i = 0; i < 17; i++){
            
            string item1;
            p3 = p4;
            p4 = temp1.find(" ", p3);
            item1 = temp1.substr(p3, p4-p3);
            p4++;
            
            switch(i){
                case 0:
                
                    person1->id = item1;
                    
                    break;
                case 1:
                
                    person1->name = item1;
                    break;
                case 2:
                    person1->contact = item1;
                    break;
                case 3:
                    
                    if(item1 == "pro_1") {
                        person1->pro = pro_1;
                    } 
                    else if(item1 == "pro_2"){
                        person1->pro = pro_2;
                    }
                    else if(item1 == "pro_3"){
                        person1->pro = pro_3;
                    }
                    else if(item1 == "pro_4"){
                        person1->pro = pro_4;
                    }
                    else if(item1 == "pro_5"){
                        person1->pro = pro_5;
                    }
                    else if(item1 == "pro_6"){
                        person1->pro = pro_6;
                    }
                    else if(item1 == "pro_7"){
                        person1->pro = pro_7;
                    }
                    else if(item1 == "pro_8"){
                        person1->pro = pro_8;
                    } 
                    break;
                case 4:
                    person1->birth = item1;
                    
                    break;
                case 5:
                    if(item1 == "children"){
                        person1->age_group = children; 
                    }
                    else if(item1 == "adolescents"){
                        person1->age_group = adolescents;
                    }
                    else if(item1 == "young_adults"){
                        person1->age_group = young_adults;
                    }
                    else if(item1 == "adults"){
                        person1->age_group = adults;
                    }
                    else if(item1 == "seniors"){
                        person1->age_group = seniors;
                    }
                    else if(item1 == "elderly"){
                        person1->age_group = elderly;
                    }
                    else if(item1 == "old"){
                        person1->age_group = old;
                    }
                    break;
                case 6:
                    if(item1 == "no_risk"){
                        person1->risk_status = no_risk;
                    }
                    else if(item1 == "low_risk"){
                        person1->risk_status = low_risk;
                    }
                    else if(item1 == "medium_risk"){
                        person1->risk_status = medium_risk;
                    }
                    else if(item1 == "high_risk"){
                        person1->risk_status = high_risk;
                    }
                    
                    break;
                case 7:
                    if(item1 == "hospital_1"){
                        person1->hospital = hospital_1;
                    }
                    else if(item1 == "hospital_2"){
                        person1->hospital = hospital_2;
                    }
                    break;
                case 9:
                    person1->local = item1;
                    break;    
                case 10:
                    
                    person1->priority_letter = stoi(item1);
                    
                    break;
                    
                case 11:
                    person1->appointment = stoi(item1);
                    break;
                case 12:
                    person1->time = stoi(item1);
                    break;
                case 13:
                    person1->register_time = stoi(item1);
                    break;
                case 14:
                    if (item1 == "1"){
                        person1->treatment = 1;
                    }
                    else if (item1 == "2"){
                        person1->treatment = 2;
                    }
                    else if (item1 == "3"){
                        person1->treatment = 3;
                    }
                    else if (item1 == "4"){
                        person1->treatment = 4;
                    }
                    else if (item1 == "5"){
                        person1->treatment = 5;
                    }
                    else if (item1 == "6"){
                        person1->treatment = 6;
                    }
                    break;
                case 15:
                
                    if (item1 == "1"){
                        person1->change = true;
                    }
                    else if(item1 == "0"){
                        person1->change = false;
                    }
                    break;
                case 8:
                    
                    if(item1 == "hospital_1"){
                        person1->hospital_treat = hospital_1;
                    }
                    else if(item1 == "hospital_2"){
                        person1->hospital_treat = hospital_2;
                    }
                    else if(item1 == "none"){
                        person1->hospital_treat = none;
                    }
                    break;
                case 16:
                    person1->withdraw = stoi(item1);
                    break;
            }
            
        }          
        obj1[m] = person1;
        m++;
        
    }
    
    infile.close();

    int32_t registered = 0;
    int32_t hospital1_waiting = 0;
    int32_t hospital2_waiting = 0;
    int32_t hospital_total = 0;
    int32_t treatment = 0;
    int32_t appointment = 0;
    int32_t sum = 0;
    int32_t waiting = 0;
    int32_t withdraw = 0;
    int32_t average = 0;
    temp2 = "";
    /*first, we calculate the amount of people who have registered in this month*/
    for(int i = 0; i<= m-1; i++){
        if((time - obj1[i]->register_time) < 30){
            registered++;
        }
        /*then we calculate the amount of people waiting in the hospital1*/
        if(((time - obj1[i]->register_time) < 30) && (obj1[i]->withdraw == -1) && (obj1[i]->treatment < 4) && (obj1[i]->hospital_treat == hospital_1)){
            hospital1_waiting++;
        }
        /*then we calculate the amount of people waiting in the hospital2*/
        if(((time - obj1[i]->register_time) < 30) && (obj1[i]->withdraw == -1) && (obj1[i]->treatment < 4) && (obj1[i]->hospital_treat == hospital_2)){
            hospital2_waiting++;
        }
        /*then we calculate the amount of people who have been treated*/
        if(((time - obj1[i]->register_time) < 30) && (obj1[i]->treatment >= 4)){
            treatment++;
        }
        /*then we calculate the amount of appointments having been delivered*/
        if(((time - obj1[i]->register_time) < 30) && (obj1[i]->appointment != 0)){
            appointment++;
        }
        /*then we calculate the waiting time in total*/
        if(((time - obj1[i]->register_time) < 30) && (obj1[i]->treatment >= 4)){
            sum = sum + obj1[i]->appointment - obj1[i]->register_time;
        }
        /*then we calculate the people who have been withdrawed*/
        if(((time - obj1[i]->register_time) < 30) && (obj1[i]->withdraw != -1)){
            withdraw++;
        }
    }
    hospital_total = hospital1_waiting + hospital2_waiting;
    average = sum / treatment;
    temp2.append("People have registered:\n");
    temp2.append(to_string(registered));
    temp2.append("\n");
    temp2.append("People waiting in hospital1:\n");
    temp2.append(to_string(hospital1_waiting));
    temp2.append("\n");
    temp2.append("People waiting in hospital2:\n");
    temp2.append(to_string(hospital2_waiting));
    temp2.append("\n");
    temp2.append("People waiting in hospitals:\n");
    temp2.append(to_string(hospital_total));
    temp2.append("\n");
    temp2.append("Appointment have been made:\n");
    temp2.append(to_string(appointment));
    temp2.append("\n");
    temp2.append("Average waiting time:\n");
    temp2.append(to_string(average));
    temp2.append("\n");
    temp2.append("People have withdrawn:\n");
    temp2.append(to_string(withdraw));
    temp2.append("\n");

    outfile<<temp2;
    outfile.close();
}

/*this function is transform profession type to string*/
string local_::addpro(profession_type m){
    if(m == pro_1){
        return "pro_1";
    }
    else if(m == pro_2){
        return "pro_2";
    }
    else if(m == pro_3){
        return "pro_3";
    }
    else if(m == pro_4){
        return "pro_4";
    }
    else if(m == pro_5){
        return "pro_5";
    }
    else if(m == pro_6){
        return "pro_6";
    }
    else if(m == pro_7){
        return "pro_7";
    }
    else if(m == pro_8){
        return "pro_8";
    }
    return "pro_8";
}

/*this function is to transform age_group_type to string*/
string local_::addage(age_group_type n){
    if(n == children){
        return "children";
    }
    else if(n == adolescents){
        return "adolescents";
    }
    else if(n == young_adults){
        return "young_adults";
    }
    else if(n == adults){
        return "adults";
    }
    else if(n == seniors){
        return "seniors";
    }
    else if(n == elderly){
        return "elderly";
    }
    else if(n == old){
        return "old";
    }
    return "children";
}

/*this function is to transform risk_status_type to string*/
string local_::addrisk(risk_status_type r){
    if(r == no_risk){
        return "no_risk";
    }
    else if(r == low_risk){
        return "low_risk";
    }
    else if(r == medium_risk){
        return "mediun_risk";
    }
    else if(r == high_risk){
        return "high_risk";
    }
    return "no_risk";
}

/*this function is to sort the list by profession*/
void local_::sort(person** list, int m){
    
    for (int count = 0; count <= m-2; count++){
        
        profession_type minimal = list[count]->pro;
        for (int count2 = count+1; count2<= m-1; count2++){
            if(list[count2]->pro < minimal){
                person* tempo;
                tempo = list[count];
                list[count] = list[count2];
                list[count2] = tempo;
                minimal = list[count]->pro;
            }
        }
    }
}

void local_::sendtime(int t){
    time = t;
}