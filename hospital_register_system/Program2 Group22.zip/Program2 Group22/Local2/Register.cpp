#include "Register.h"
#include <stddef.h>
#include "person.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <ctime>
#include "function.h"
#include "UI_function.h"
#include "recieve.h"
#include "treat.h"
#include "local.h"
#include "local.cpp"

#include "hashset.cpp"
#include "Btree.h"
#include "BPtree.h"

#define item_num 11

using namespace std;
void display(List* pt);

int main(){
      /* Initializing the data*/
    hashset<person>* person_hash = new hashset<person>;
    string local = "local_2";
    int time = 0;
    bool time_change = 0;
    int count = 0;
    local_ test;
    cout<<"Start Initializeing..."<<endl;
    string temp;
    ifstream infile;
    ofstream outfile;
    infile.open("local.txt",ios::in);
    outfile.open("temp.txt",ios::out);

    //build list from the record data
    List* person_inform = new List;
    BTree<int>* btree1 = new BTree<int>;
    BPlusTree* person_tree = new BPlusTree;
    BPlusTree* medical_tree = new BPlusTree;
    BPlusTree* register_tree = new BPlusTree;
    BPlusTree* treatment_tree = new BPlusTree;
    cout<<"start Read"<<endl;
    //get the historical data
    while(infile.eof() == 0){
        getline(infile, temp);
        if(temp.length() == 0){
            break;
        }

        size_t p1 = 0;
        size_t p2 = 0;
        person* info = new person;

        //read and seperate the item and record in the list
        for(int i = 1; i <= 20; i ++){
            string item;
            p1 = p2;
            p2 = temp.find(" ", p1);
            item = temp.substr(p1, p2-p1);
            p2 ++;
            switch (i){
                case 1:
                    info->id = item;
                    break;

                case 2:
                    info->medical_id = item;
                    break;
                case 3:
                    info->regis_id = item;
                    break;
                case 4:
                    info->treat_id = item;
                    break;
                case 5:
                    info->name = item;
                    break;

                case 6:
                    info->contact = item;
                    break;

                case 7:
                    info->pro = setpro(item);
                    break;

                case 8:
                    info->birth = item;
                    break;

                case 9:
                    info->age_group = setage(item);
                    break;

                case 10:
                    info->risk_status = setrisk(item);
                    break;

                case 11:
                    info->hospital = sethospital(item);
                    break;

                case 12:
                    info->hospital_treat = sethospital(item);
                    break;

                case 13:
                    info->local = item;
                    break;

                case 14: 
                    info->priority_letter = stoi(item);
                    break;

                case 15:
                    info->appointment = stoi(item);
                    break;

                case 16:
                    info->time = stoi(item);
                    break;

                case 17:
                    info->register_time = stoi(item);
                    break;

                case 18:
                    if(item == "0"){
                        info->treatment = 0;
                    }
                    else{
                        info->treatment = 1;
                    }
                    break;

                case 19:
                    if(item == "0"){
                        info->change = 0;
                    }
                    else{
                        info->change = 1;
                    }
                    break;

                case 20:
                    info->withdraw = stoi(item);
                    break;

                default:
                    break;
            }            
        }
        
        //append into the list
        person_inform->previous_append(info);
        person_tree->Insert(stoi(info->id));
        medical_tree->Insert(stoi(info->medical_id));
        register_tree->Insert(stoi(info->regis_id));
        treatment_tree->Insert(stoi(info->treat_id));
        btree1->BTree_insert(stoi(info->contact),info);
        person_hash->add(info);
        
    }
    infile.close();
    outfile.close();
    cout<<person_inform->getnum()<<"items loaded"<<endl;
    cout<<"Finish Inizializing!"<<endl;

    //UI operation
    while(1 == 1){
        cout<<"\n\n\n       "<<time<<"day\n";
        cout<<"Welcome to register system"<<endl;
        
        cout<<"Please choose your service"<<endl;
        
        cout<<"1.along/insert in B+   2.batch   3.view   4.sent   5.modify   6.withdraw   7.receive   8.next day   9.BTree"<<endl;
        cout<<"\n10.show the B+ tree\n11.remove from B+ tree\n12.rebalence the B+ tree (split/merge)\n13.check whether B+ tree is balenced\n14.search the B+ tree"<<endl;
        cout<<"\n15.show the medical-state B+ tree\n16.search the medical-state B+ tree"<<endl;
        cout<<"\n17.show the registration-state B+ tree\n18.search the registration B+ tree"<<endl;
        cout<<"\n19.show the treatment-state B+ tree\n20.search the treatment-state B+ tree"<<endl;
        int choice;
        cin>>choice;
        int y=0;
        bool success;
        char sPath[255]={0, };
        switch (choice){
            case 1:
                person_inform->append(get_singe_person(time, person_inform, local, person_hash));
                break;

            case 2:
                appendall(person_inform, time, local, person_hash);
                break;

            case 3:
                viewdata(person_inform, person_hash);
                break;

            case 4:
                sentdata(person_inform, time);
                break;

            case 5:
                change_info(person_inform);
                break;

            case 6:
                withdraw(person_inform, time);
                break;
            
            case 7:
                receive_data(person_inform);
                break;

            case 8:
                count += 2;
                test.sendtime(time);
                break;

            case 9:
                int contact;
                btree1->printpoint();
                cout << "Please enter one contact:\n";
                cin >> contact;
                
                BTnode<int>* a;
                a = btree1->BTree_find(btree1->root,contact);
                int b;
                b = btree1->BTree_findindex(btree1->root,contact);
                cout << a->data[b]->id;
                break;
            case 10:
                person_tree->PrintTree();
                break;
            case 11:
                printf("The id of the person you want to delete：");
                scanf("%d", &y);
                success = person_tree->Delete(y);
                if (true == success)
                {
                    printf("\nsuccessed!\n\n");
                }
                else
                {
                    printf("\nfailed!\n\n");
                }
                break;
            case 12:
                person_tree = person_tree->RotateTree();
                printf("\nsuccessed!\n\n");
                break;
            case 13:
                success = person_tree->CheckTree();
                if (true == success)
                {
                    printf("\nsuccessed!\n\n");
                }
                else
                {
                    printf("\nfailed!\n\n");
                }
                break;
            case 14:
                printf("The id of the person you want to search：");
                scanf("%d", &y);
                (void)person_tree->Search(y, sPath);
                person_inform->search(y);
                printf("\n%s", sPath);
                break;
            case 15:
                medical_tree->PrintTree();
                break;
            case 16:
                printf("The medical-state id of the person you want to search：");
                scanf("%d", &y);
                (void)medical_tree->Search(y, sPath);
                person_inform->search_m(y);
                printf("\n%s", sPath);
            case 17:
                register_tree->PrintTree();
                break;
            case 18:
                printf("The register-state id of the person you want to search：");
                scanf("%d", &y);
                (void)register_tree->Search(y, sPath);
                person_inform->search_r(y);
                printf("\n%s", sPath);
                break;
            case 19:
                treatment_tree->PrintTree();
                break;
            case 20:
                printf("The treatment-state id of the person you want to search：");
                scanf("%d", &y);
                (void)treatment_tree->Search(y, sPath);
                person_inform->search_t(y);
                printf("\n%s", sPath); 
                break;
            default:
                goto quit;
        }




        /*report operation with time*/
        if(time%7 == 0 && time_change == 1){ 
            test.report1();
        }

        if(time%30 == 0 && time_change == 1){
            test.report2();
        }

        time_change = 0;
        //Recieve from center

        //time increase
        if(count == 2){
            //end of a day start record treatment infomation and renew the record data
            cout<<"start treatment "<<time<<" day"<<endl;
            treat_operation(person_inform, time);
            renew_record(person_inform);


            count = 0;
            time ++;
            time_change = 1;
        }
        
    }

quit: cout<<"quit!";
    
}