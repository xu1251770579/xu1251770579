#include "Register.h"
#include <stddef.h>
#include "person.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <ctime>
#include "function.h"

using namespace std;

/*
function name: receive data

input: person's list

function: receive data from center and renew the data in the person's list

output: none
*/
void receive_data(List* person_list){
    /*open the received file*/
ifstream infile;
infile.open("new.txt");
string temp;
int number = 0;

/* get data from file */
while(infile.eof() == 0){
        getline(infile, temp);
        if(temp.length() == 0){
            break;
        }
        
        size_t p1 = 0;
        size_t p2 = 0;
        person* info = new person;
        string item;

        /*seperate an item and then renew the old data*/
        for(int i = 1; i <= 15; i ++){
            
            p1 = p2;
            p2 = temp.find(" ", p1);
            item = temp.substr(p1, p2-p1);
            p2 ++;
            switch (i){
                case 1:
                    info->id = item;
                    break;

                case 2:
                    info->name = item;
                    break;

                case 3:
                    info->contact = item;
                    break;

                case 4:
                    info->pro = setpro(item);
                    break;

                case 5:
                    info->birth = item;
                    break;

                case 6:
                    info->age_group = setage(item);
                    break;

                case 7:
                    info->risk_status = setrisk(item);
                    break;

                case 8:
                    info->hospital = sethospital(item);
                    break;

                case 9:
                    info->hospital_treat = sethospital(item);
                    break;

                case 10: 
                    info->priority_letter = stoi(item);
                    break;

                case 11:
                    info->appointment = stoi(item);
                    break;

                case 12:
                    info->register_time = stoi(item);
                    break;

                case 13:
                    if(item == "0"){
                        info->treatment = 0;
                    }
                    else{
                        info->treatment = 1;
                    }
                    break;

                case 14:
                    if(item == "0"){
                        info->change = 0;
                    }
                    else{
                        info->change = 1;
                    }
                    break;

                case 15:
                    info->time = stoi(item);
                    break;


                default:
                    break;
            }            
        }

        /* get the item by id and renew it*/
        List_node* pt = person_list->get_by_id(info->id);
        if(pt == NULL){
            cout<<"id: "<<info->id<<" not found!"<<endl;
            delete info;
            continue;
        }
        pt->sethospital_treat(info->hospital_treat);
        pt->setappoint(info->appointment);
        pt->settime(info->time);
        delete info;
        number ++;
    }
    infile.close();
    remove("../localinput_1/new.txt");
    ofstream newfile;
    newfile.open("../localinput_1/new.txt");
    newfile.close();
    cout<<"receive "<<number<<" item"<<endl;
}