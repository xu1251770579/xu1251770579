#ifndef local_h
#define local_h
#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <stddef.h>
#include <fstream>
#include <string>
#include "person.h"

using std::cout;
using std::cin;
using std::endl;

class local_
{
    public:
    int time = 8;
    
    void report1();
    void report2();
    std::string addpro(profession_type m);
    std::string addage(age_group_type n);
    std::string addrisk(risk_status_type r);
    void sort(person** list, int m);
    private:
};



#endif