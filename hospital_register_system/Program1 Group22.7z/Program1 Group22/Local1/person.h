#include <stdlib.h>
#include <stddef.h>
#include <string>
#include <iostream>
#include "function.h"
#ifndef person_h
#define person_h
using namespace std;
class person;

/*class for record personal infomation*/

class person
{
    public:
        person(){
            priority_letter = 0;
            appointment = 0;
            register_time = 0;
            treatment = 0;
            change = 0;
            absolute = 0;
        }

        person(string id_num,string name_,string contact_,profession_type pro_,
                string birth_,hospital_type hospital_,risk_status_type risk){

            int year,age;
            id = id_num;
            name = name_;
            contact = contact_;
            pro = pro_;
            birth = birth_;
            
            for(int i = 0; i<4 ; i++){
                year = year*10 + (birth[i] - '0'); 
            }
            age = 2021 -year;
            if(age<=12){
                age_group = children;
            }else if(age<=18){
                age_group = adolescents;
            }else if(age <= 35){
                age_group = young_adults;
            }else if(age <= 50){
                age_group = adults;
            }else if(age <= 65){
                age_group = seniors;
            }else if(age <= 75){
                age_group = elderly;
            }else{
                age_group = old;
            }
            priority_letter = 0;
            appointment = 0;
            register_time = 0;
            treatment = 0;
            change = 0;
            absolute = 0;
            risk_status =risk;
        }
        
        std::string id;
        std::string name;
        std::string contact;
        profession_type pro;
        std::string birth;
        age_group_type age_group;
        risk_status_type risk_status;
        hospital_type hospital;
        hospital_type hospital_treat;
        int32_t priority_letter;
        int32_t appointment;
        int32_t time;
        int32_t register_time;
        bool treatment;
        bool change;
        int withdraw;
        int absolute;
        string local;
        
        

};

#endif 
