#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include "FibHeap.h"
#include <fstream>
#include <sstream>
#include <string>
#include <stddef.h>
using namespace std;
#ifndef FibHeap_Func_2_h
#define FibHeap_Func_2_h

//its the compare with person to person
int center::compare(fib_node *pt_1,fib_node *pt_2)
{
    //First see whether there is a prior person
    if (pt_1->node_person->absolute==1&&pt_2->node_person->absolute==0)
    {
        return 1;
    }
    else if (pt_2->node_person->absolute==1&&pt_1->node_person->absolute==0)
    {
        return 0;
    }
    //compare the risk state
    if (pt_1->node_person->risk_status==high_risk&&  pt_2->node_person->risk_status!=high_risk){
        return 0;
    }else if(pt_1->node_person->risk_status!=high_risk&&  pt_2->node_person->risk_status==high_risk){
        return 1;
    }
    
    
    //compare the profession
    if (pt_1->node_person->pro<pt_2->node_person->pro)
    {
        return 1;
    }
    else if (pt_1->node_person->pro>pt_2->node_person->pro)
    {
        return 0;
    }
    
    //compare the age group
    if (pt_1->node_person->age_group<pt_2->node_person->age_group)
    {
        return 1;
    }
    else if (pt_1->node_person->age_group>pt_2->node_person->age_group)
    {
        return 0;
    }

    //compare the registration time
    if (pt_1->node_person->register_time<pt_2->node_person->register_time)
    {
        return 1;
    }
    else if (pt_1->node_person->register_time>pt_2->node_person->register_time)
    {
        return 0;
    }
    
    return 1;
}

// find function find(return) the node by the person id
//the root is use for recurisive
fib_node* center::find(fib_node* root, string id_){
    fib_node* t = root;
    fib_node* p = NULL;
    if(root == NULL){
        return NULL; 
    }
    do{
        if(t->node_person->id == id_){
            p = t;
            break;
        }else{
            p = find(t->child,id_);
            if(p!= NULL){
                break;
            }
        }
        t = t->right;
    }while(t!=root);
    return p;
}


/*this is the delete min*/
//link is connect the same degree use for deletemin
fib_node* center::link(fib_node* a,fib_node* b){
    if(a != b){
        b->right->left = b->left;
        b->left->right = b->right;

        b->parent = a;
        if(a->child!=NULL){
            b->right = a->child->right;
            b->left = a->child;
            a->child->right = b;
            b->right->left = b;
        }else{
            a->child = b;
            b->left = b;
            b->right = b;
        }
            a->degree++;    
    }
    return a;
}
//get the pt_min out the root chain 
fib_node* center::extractMin()
{
    fib_node *p = pt_min;

    if (p == p->right)
        pt_min = NULL;
    else
    {
        p->right->left = p->left;
        p->left->right = p->right;
        pt_min = p->right;
    }
    p->right = p;
    p->left = p;
    return p;
}
//this is consolidate all the same degree root
//use in the deletemin
void center::consolidate(){
    fib_node** A = new fib_node*[node_num];
    fib_node* x;
    fib_node* y;
    fib_node* z;
    int d;
    for(int i=0;i<node_num;i++){
        A[i] = NULL;
    }
    while(pt_min != NULL){
        x = extractMin();                
        d = x->degree;                    
        
        while (A[d] != NULL)
        {
            y = A[d];
            if(compare(x,y) == 0){
                z = x;
                x = y;
                y = z;
            }                
            link(x, y);    
            A[d] = NULL;
            d++;
        }
        A[d] = x;
    }
    for (int i=0; i<node_num; i++)
    {
        if (A[i] != NULL)
        {
            if (pt_min == NULL)
                pt_min = A[i];
            else
            {
                A[i]->right = pt_min->right;
                A[i]->left = pt_min;
                pt_min->right->left = A[i];
                pt_min->right = A[i];
                if (compare(A[i],pt_min)==1)
                    pt_min = A[i];
            }
        }
    }
}

//fib delete the min_person
void center::delete_min(){
    fib_node* z = pt_min;
    fib_node* a;
    fib_node* b;
    if(z != NULL){
        a=z->child;
        b=a;
        do{
            if(a == NULL){
                break;
            }
            a=b;
            b=a->right;
            a->right = pt_min->right;
            a->left = pt_min;
            pt_min->right = a;
            a->right->left = a;
            a->parent = NULL;
        }while(b !=z->child);
        if(z->right == z){
            pt_min = NULL;
            node_num = 0;
            return;
        }
        z->right->left = z->left;
        z->left->right = z->right;
        pt_min = z->right;
        if(pt_min->right !=pt_min){
            consolidate();
        }
        node_num--;
    }
}



//fib insert the node
void center::insert(fib_node* node){
    if(pt_min == NULL){
        pt_min = node;
        pt_min->left = node;
        pt_min->right = node;
        return;
    }
    node->right = pt_min->right;
    node->left = pt_min;
    pt_min->right = node;
    node->right->left = node;
    if(compare(node,pt_min) == 1){
        pt_min = node;
    }
    node_num++;
    return;
}
 


/*this is the delete part
we need to decrese the key and put it to pt_min
then delete min*/
void center::cut(fib_node* parent,fib_node* child){
    if(child->right == child){
        parent->child = NULL;
    }else{
        child->left->right = child->right;
        child->right->left = child->left;
        if(parent ->child == child){
            parent ->child = child ->right;
        }
    }
    child->right = pt_min->right;
    child ->left = pt_min;
    pt_min ->right->left = child;
    pt_min->right = child;
    child ->parent = NULL;
    child ->if_mark = false;
    parent->degree--;
    return;
}
//use for decrease the node
void center::cascading_cut(fib_node* a){
    fib_node* b = a->parent;
    if(b != NULL){
        if(b->if_mark ==false){
            b->if_mark = true;
        }else{
            cut(b,a);
            cascading_cut(b);
        }
    }
    return;
}
//this is decrease the key 
//we use the value absolute to represent the min(the max priority)
void center::decrease(string id){
    fib_node* a = find(pt_min,id);
    fib_node* b;
    a->node_person->absolute = 1;
    b = a->parent;
    if(b != NULL && b->node_person->absolute != 1){
        cut(b,a);
        cascading_cut(b);
    }
    if(compare(pt_min,a) == 0){
        pt_min = a;
    }
}

//decrese the person and delete min
void center::delete_person(string id){
    decrease(id);
    delete_min();
    return;
}




//display only the root list and the degree
//display the ddl list with id
void center::display(){
    fib_node* i;
    cout<<"here is the root list of the fib_tree:"<<"\n";
    if(pt_min == NULL){
        cout<<"the fib tree is empty\n";
    }else{
        cout<<"the min person id is "<<pt_min->node_person->id<<"\n";
        cout<<"the min degree is "<<pt_min->degree<<"\n";
        for(i = pt_min->right;i!=pt_min;i = i->right){
            cout<<"the person id is "<<i->node_person->id<<"\n";
            cout<<"the degree is "<<i->degree<<"\n";
        }
        cout<<"\nhere is the ddl list\n";
        for(int j = 0;j<ddl_person_num;j++){
            cout<<"the person id is "<<ddl_person[j]->id<<"\n";
            cout<<"the ddl is "<<ddl_person[j]->priority_letter<<"\n";
        }
    }
    return;
}
//this is the delete the item in ddl list with id
void center::delete_ddl(string id){
    for(int i = 0;i<ddl_person_num;i++){
        if(ddl_person[i]->id == id){
            for(i;i<ddl_person_num - 1;i++){
                ddl_person[i] = ddl_person[i+1];
            }
            ddl_person_num--;
            break;
        } 
    }
}
//this is insert the ddl with id
void center::insert_ddl(person* person_)
{
    int if_find = 0;
            if(person_->priority_letter>0){
                for(int i =0;i<ddl_person_num;i++){
                    if(ddl_person[i]->priority_letter>=person_->priority_letter){
                        for(int j = ddl_person_num;j>i;j--){
                            ddl_person[j] = ddl_person[j-1];
                        }
                        ddl_person[i]=person_;
                        ddl_person_num++;
                        if_find = 1;
                        break;
                    }
                }
                if(if_find == 0){
                    ddl_person[ddl_person_num] =person_;
                    ddl_person_num++;
                }
            }
            return;
}
#endif