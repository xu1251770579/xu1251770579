#include "Register.h"
#include <stddef.h>
#include "person.h"
#include <fstream> 
#include <sstream>  
#include <iostream>
#include <string>
#include <ctime>
#include "function.h"
#include "UI_function.h"
#include "recieve.h"
#include "treat.h"
#include "local.h"
#include "local.cpp"

#define item_num 11

using namespace std;
void display(List* pt);

int main(){
      /* Initializing the data*/
    string local = "local_2";
    int time = 0;
    bool time_change = 0;
    int count = 0;
    local_ test;
    cout<<"Start Initializeing..."<<endl;
    string temp;
    ifstream infile;
    ofstream outfile;
    infile.open("local.txt",ios::in);
    outfile.open("temp.txt",ios::out);

    //build list from the record data
    List* person_inform = new List;
    
    //get the historical data
    while(infile.eof() == 0){
        getline(infile, temp);
        if(temp.length() == 0){
            break;
        }

        size_t p1 = 0;
        size_t p2 = 0;
        person* info = new person;

        //read and seperate the item and record in the list
        for(int i = 1; i <= 17; i ++){
            string item;
            p1 = p2;
            p2 = temp.find(" ", p1);
            item = temp.substr(p1, p2-p1);
            p2 ++;
            switch (i){
                case 1:
                    info->id = item;
                    break;

                case 2:
                    info->name = item;
                    break;

                case 3:
                    info->contact = item;
                    break;

                case 4:
                    info->pro = setpro(item);
                    break;

                case 5:
                    info->birth = item;
                    break;

                case 6:
                    info->age_group = setage(item);
                    break;

                case 7:
                    info->risk_status = setrisk(item);
                    break;

                case 8:
                    info->hospital = sethospital(item);
                    break;

                case 9:
                    info->hospital_treat = sethospital(item);
                    break;

                case 10:
                    info->local = item;
                    break;

                case 11: 
                    info->priority_letter = stoi(item);
                    break;

                case 12:
                    info->appointment = stoi(item);
                    break;

                case 13:
                    info->time = stoi(item);
                    break;

                case 14:
                    info->register_time = stoi(item);
                    break;

                case 15:
                    if(item == "0"){
                        info->treatment = 0;
                    }
                    else{
                        info->treatment = 1;
                    }
                    break;

                case 16:
                    if(item == "0"){
                        info->change = 0;
                    }
                    else{
                        info->change = 1;
                    }
                    break;

                case 17:
                    info->withdraw = stoi(item);
                    break;

                default:
                    break;
            }            
        }
        
        //append into the list
        person_inform->previous_append(info);
    }
    infile.close();
    outfile.close();
    cout<<person_inform->getnum()<<"items loaded"<<endl;
    cout<<"Finish Inizializing!"<<endl;

    //UI operation
    while(1 == 1){
        cout<<"       "<<time<<"day\n";
        cout<<"Welcome to register system"<<endl;
        
        cout<<"Please choose your service"<<endl;
        
        cout<<"1.along   2.batch   3.view   4.sent   5.modify   6.withdraw   7.receive   8.next day"<<endl;
        int choice;
        cin>>choice;

        switch (choice){
            case 1:
                person_inform->append(get_singe_person(time, person_inform, local));
                break;

            case 2:
                appendall(person_inform, time, local);
                break;

            case 3:
                viewdata(person_inform);
                break;

            case 4:
                sentdata(person_inform, time);
                break;

            case 5:
                change_info(person_inform);
                break;

            case 6:
                withdraw(person_inform, time);
                break;
            
            case 7:
                receive_data(person_inform);
                break;

            case 8:
                count += 2;
                break;
            default:
                goto quit;
        }




        /*report operation with time*/
        if(time%7 == 0 && time_change == 1){
            test.report1();
        }

        if(time%30 == 0 && time_change == 1){
            test.report2();
        }

        time_change = 0;
        //Recieve from center

        //time increase
        if(count == 2){
            //end of a day start record treatment infomation and renew the record data
            cout<<"start treatment "<<time<<" day"<<endl;
            treat_operation(person_inform, time);
            renew_record(person_inform);


            count = 0;
            time ++;
            time_change = 1;
        }
        
    }

quit: cout<<"quit!";
    
}